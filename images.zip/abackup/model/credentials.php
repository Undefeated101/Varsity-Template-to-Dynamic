<?php

$host = 'Localhost';
$user = 'root';
$password = '';
$database = 'webmania';





?>