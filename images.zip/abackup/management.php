<?php
$title = 'Management';
$content = '
    <h2> Post </h2>
     <a href="postadd.php "> <h3>  Add a new POST  </h3> </a>  
      <a href="postOverview.php"> <h3>   Update or Delete </h3>  </a>  
      <a href="uploadImg.php"> <h3>   Upload Images</h3>  </a> 
    '
        ;


include 'master.php';


?>
